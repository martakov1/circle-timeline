import {
    gsap
} from "gsap";

var blueSpeed = 2;
// var boxTimeline = gsap.timeline;

gsap.from(".blue-box", {
    duration: blueSpeed,
    x: 700,
    y: 700,
    borderRadius: "60px"
});

gsap.to(".blue-box", {
    duration: blueSpeed,
    y: 100,
    borderRadius: "3000px",
    delay: blueSpeed
});



// boxTimeline.to("#box", {duration: 4, rotation: 240})
// //             .to("#box", {duration: 4,rotation: -240, x: "0px"});