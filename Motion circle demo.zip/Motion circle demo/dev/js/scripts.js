import * as Demo from './demo.js';
import {
    gsap
} from "gsap";

//keeping codekit quiet//
console.log(Demo);
console.log(gsap);
